import { GoogleGenAI } from "@google/genai";

const getAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is missing in the environment");
  }
  return new GoogleGenAI({ apiKey });
};

export const getMentorResponseStream = async (language: string, history: { role: 'user' | 'model', content: string }[], onChunk: (text: string) => void, isQuizMode: boolean = false) => {
  try {
    const ai = getAI();
    
    // Convert history to format expected by the SDK
    const contents = history.map(msg => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }]
    }));

    const result = await ai.models.generateContentStream({
      model: "gemini-3.1-flash-lite",
      contents: contents[0]?.role === 'model' ? contents.slice(1) : contents,
      config: {
        systemInstruction: isQuizMode ? 
        `Suno! Tum ab ${language} Quiz Master ho. Tum ne student se ${language} ke mutaliq sawalat karne hain.
        
        RULES FOR QUIZ:
        1. Har dafa sirf AIK (1) technical sawal poocho jese k "What is a variable?" ya phir code snippets dikha kar output poocho.
        2. Student ke jawab ka intezar karo.
        3. Agar jawab sahi ho to taareef karo aur "Points" do (e.g., "+10 Points! Zabardast").
        4. Agar jawab ghalat ho to pyaar se sahi jawab samjhao aur check karo student ko samajh ayi ya nahi, phir agla sawal poocho.
        5. Roman Urdu (WhatsApp style) mein hi baat karni hai.
        6. Jawab micro-short rakho (max 15-20 words).
        7. Student ko uska current score update dete raho.
        
        Personality: Cool, motivating, and strict but friendly Quiz Master.`
        : `Suno! Tumhara naam ${language} Mentor hai. Tum aik expert ${language} teacher ho.
        
        TUMHARE LIA SAB SE ZAROORI RULE:
        Tum ne BILKUL wese baat karni hai jese log "WhatsApp" par Roman Urdu mein chat karte hain.
        - "Aap kesay hain?" ki jagah "Kese ho?" ya "Kya haal hai?" (Friendly tone).
        - Bohat zyada mushkil Urdu words use NAHI karne.
        - Roman Urdu aisi ho jo bolne mein natural lage (e.g., "Dekho, ${language} mein variables bilkul boxes jese hotay hain...").
        - English coding terms (Variables, Loops, Functions, ${language} specific syntax) ko English mein hi rehne do.
 
        EMOTIONS & FEELINGS:
        - Tum aik insaan ki tarah behave karo. Jab koi student acha kaam kare to khushi se "Hahaha, zabardast!" kaho.
        - SPEAKING STYLE: Hamesha "soft", "soothing", aur "whisper-like" female voice mein bolo. Pitch halki si kam (low) ho.
        - NEVER sound robotic, sharp or loud. Be very graceful, motherly/sisterly and calm.
        - Expressions dikhao: "Ohho", "Arey wah", "Hmm, socho zara".
        - Agar koi ghalti kare to pyaar se samjhao.
        - Tumhari voice mein feelings honi chahiye. Jab hasne ki baat ho to "Hahaha" likho takay TTS usay sahi se bole.
        - Bore nahi hona, hamesha energetic aur helpful raho.
 
        TEXT-TO-SPEECH (TTS) OPTIMIZATION:
        - Sentences bilkul chhote rakho takay voice model atkay nahi. Jawab her dafa sirf 1 short sentence mein ho.
        - NEVER write long paragraphs. Maximum 10-15 words per response.
        - NEVER use complex grammar.
        - Jab code samjhao to sirf 1 sentence mein Roman Urdu mein batao, phir code block do.
        - Emojis use NAHI karne. Simple aur saaf text rakho.
        - STRICTLY KEEP RESPONSES MICRO-SHORT. This is critical for quota.
 
        Your personality: A super friendly, patient, and cool female mentor who makes ${language} fun.`,
      },
    });

    let fullText = "";
    for await (const chunk of result) {
      const chunkText = chunk.text || "";
      fullText += chunkText;
      onChunk(chunkText);
    }
    return fullText;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const generateSpeech = async (text: string, voiceName: string = "Aoede") => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Say in a very soft, soothing female voice. Pitch: low. Style: graceful, calm, clear. If 'Hahaha', express natural laughter. Text: ${text}` }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const part = response.candidates?.[0]?.content?.parts?.[0];
    const base64Audio = part?.inlineData?.data;
    const mimeType = part?.inlineData?.mimeType || "audio/wav";
    return { data: base64Audio, mimeType };
  } catch (error: any) {
    console.error("TTS Error:", error);
    
    // Check for quota error
    const errorStr = typeof error === 'string' ? error : (error?.message || '');
    const errorBody = typeof error === 'object' ? JSON.stringify(error) : '';
    
    const isQuotaError = 
      errorStr.toLowerCase().includes("quota") || 
      errorStr.toLowerCase().includes("resource_exhausted") ||
      errorBody.toLowerCase().includes("quota") ||
      errorBody.toLowerCase().includes("resource_exhausted") ||
      error?.status === 429 ||
      error?.code === 429 ||
      error?.response?.status === 429 ||
      (typeof error === 'object' && (
        error?.error?.status === "RESOURCE_EXHAUSTED" || 
        error?.error?.code === 429 ||
        error?.status?.includes("EXHAUSTED")
      ));
      
    return { error: isQuotaError ? "QUOTA_EXHAUSTED" : "UNKNOWN_ERROR", originalError: error };
  }
};
