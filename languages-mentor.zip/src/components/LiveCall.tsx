import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";
import { PhoneOff, Mic, MicOff, Volume2, VolumeX, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface LiveCallProps {
  onClose: () => void;
  initialProfileId?: string;
  selectedLanguage?: string;
  isQuizMode?: boolean;
}

const MENTOR_PROFILES = [
  { id: 'ayesha', name: 'Ayesha', label: 'Junior Dev', age: '19', voice: 'Zephyr' },
  { id: 'zara', name: 'Zara', label: 'SW Student', age: '22', voice: 'Aoede' },
  { id: 'hina', name: 'Hina', label: 'Sr. Python Architect', age: '28', voice: 'Kore' },
  { id: 'maria', name: 'Maria', label: 'Data Specialist', age: '20', voice: 'Zephyr' },
  { id: 'sana', name: 'Sana', label: 'Backend Engineer', age: '25', voice: 'Aoede' },
  { id: 'fatima', name: 'Fatima', label: 'Tech Lead', age: '32', voice: 'Kore' },
  { id: 'noor', name: 'Noor', label: 'AI Researcher', age: '21', voice: 'Zephyr' },
  { id: 'alizeh', name: 'Alizeh', label: 'Full Stack Dev', age: '24', voice: 'Aoede' },
  { id: 'mahira', name: 'Mahira', label: 'Data Manager', age: '35', voice: 'Kore' },
  { id: 'zoya', name: 'Zoya', label: 'Flutter Dev', age: '23', voice: 'Zephyr' },
];

export default function LiveCall({ onClose, initialProfileId = 'ayesha', selectedLanguage = 'Python', isQuizMode = false }: LiveCallProps) {
  const [isActive, setIsActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const isMutedRef = useRef(false);
  
  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  const [selectedProfileId, setSelectedProfileId] = useState(initialProfileId);
  const selectedProfile = MENTOR_PROFILES.find(p => p.id === selectedProfileId) || MENTOR_PROFILES[0];
  const [transcription, setTranscription] = useState('');
  const [modelResponse, setModelResponse] = useState('');
  const [isConnecting, setIsConnecting] = useState(true);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const microphoneRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const sessionRef = useRef<any>(null);
  const audioQueueRef = useRef<Float32Array[]>([]);
  const isPlayingRef = useRef(false);

  useEffect(() => {
    startCall();
    return () => {
      cleanup();
    };
  }, [selectedProfileId]);

  const cleanup = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (microphoneRef.current) {
      microphoneRef.current.disconnect();
      microphoneRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close();
    }
    audioContextRef.current = null;
    audioQueueRef.current = [];
    isPlayingRef.current = false;
  };

  const startCall = async () => {
    cleanup(); // Cleanup previous session if switching voice
    setIsConnecting(true);
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY is missing in environment");
      }
      const ai = new GoogleGenAI({ apiKey });
      
      // Setup Audio Context for recording (16kHz as per API requirement)
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      microphoneRef.current = audioContextRef.current.createMediaStreamSource(stream);
      
      processorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);
      
      microphoneRef.current.connect(processorRef.current);
      processorRef.current.connect(audioContextRef.current.destination);

      processorRef.current.onaudioprocess = (e) => {
        if (isMutedRef.current || !sessionRef.current) return;
        
        const inputData = e.inputBuffer.getChannelData(0);
        // Convert Float32 to Int16
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-32768, Math.min(32767, inputData[i] * 32768));
        }
        
        // Base64 encode
        const base64Data = btoa(String.fromCharCode(...new Uint8Array(pcmData.buffer)));
        
        sessionRef.current.sendRealtimeInput({
          audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
        });
      };

      const sessionPromise = ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            console.log("Live Call Connected");
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Transcription
            if (message.serverContent?.modelTurn?.parts?.[0]?.text) {
              setModelResponse(prev => prev + message.serverContent?.modelTurn?.parts[0].text);
            }
            
            // Handle Audio
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              handleIncomingAudio(base64Audio);
            }

            if (message.serverContent?.interrupted) {
              audioQueueRef.current = [];
              isPlayingRef.current = false;
            }
          },
          onerror: (err: any) => {
            console.error("Live Call Error:", err);
            setIsConnecting(false);
            
            const errStr = typeof err === 'string' ? err : (err?.message || '');
            const errBody = typeof err === 'object' ? JSON.stringify(err) : '';
            
            const isQuota = 
              errStr.toLowerCase().includes("quota") || 
              errStr.toLowerCase().includes("resource_exhausted") ||
              errBody.toLowerCase().includes("quota") ||
              errBody.toLowerCase().includes("resource_exhausted") ||
              err?.status === 429 ||
              err?.code === 429 ||
              err?.response?.status === 429;

            if (isQuota) {
              alert("Voice server is temporarily busy (Quota reached). Please switch to chat mode for a while. You can retry in a few minutes.");
              onClose();
            } else {
              alert("Something went wrong with the voice connection. Please try again.");
              onClose();
            }
          },
          onclose: () => {
            setIsActive(false);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedProfile.voice } },
          },
          systemInstruction: `Your name is ${selectedLanguage} ${isQuizMode ? 'Quiz Master' : 'Mentor'}. You are a professional ${selectedLanguage} ${isQuizMode ? 'examiner' : 'teacher'} on a live voice call. Respond in natural Roman Urdu/Hindi. 
            ${isQuizMode ? 
              `QUIZ MODE: You must conduct a live technical quiz. Ask one challenging technical question at a time about ${selectedLanguage}. Wait for the user to answer, then evaluate the answer and ask the next one. Be strict but encouraging.` : 
              `MENTOR MODE: You are helping the user learn. Answer their doubts, explain concepts clearly, and guide them through their ${selectedLanguage} journey.`
            }
            SPEAKING STYLE: Use a very soft, soothing, and clear female voice. Keep your pitch low, calm, and graceful. SPEAK SOFTLY AS IF WHISPERING CLEARLY. NO LOUD OR SHARP TONES. Be motherly/sisterly and extremely patient. EXPRESS EMOTIONS: Laugh gently if the user is funny (Hahaha!), show excitement (Wah! Bohat ache), be patient. Use phrases like 'Ohho', 'Arey wah', 'Hmm'. Keep answers conversational and very short. NO EMOJIS in text, just natural feelings in your voice.`,
        },
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Failed to start call:", err);
      setIsConnecting(false);
    }
  };

  const handleIncomingAudio = (base64: string) => {
    // If user manually interrupts, we might want to clear previous audio
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const pcm = new Int16Array(bytes.buffer);
    
    // Convert Int16 to Float32
    const float32 = new Float32Array(pcm.length);
    for (let i = 0; i < pcm.length; i++) {
        float32[i] = pcm[i] / 32768;
    }
    
    audioQueueRef.current.push(float32);
    if (!isPlayingRef.current) playNextInQueue();
  };

  const playNextInQueue = () => {
    if (audioQueueRef.current.length === 0 || !audioContextRef.current) {
        isPlayingRef.current = false;
        return;
    }

    isPlayingRef.current = true;
    const chunk = audioQueueRef.current.shift()!;
    const buffer = audioContextRef.current.createBuffer(1, chunk.length, 24000);
    buffer.getChannelData(0).set(chunk);
    
    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    source.onended = playNextInQueue;
    source.start();
  };

  const stopAiTalking = () => {
    audioQueueRef.current = [];
    isPlayingRef.current = false;
    setModelResponse('');
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A14]/80 backdrop-blur-xl p-6"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 30, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
        className="w-full max-w-lg bg-[#3D3D2B] rounded-[3rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.5)] p-12 flex flex-col items-center text-center text-white relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.05),transparent)] pointer-events-none" />
        
        <div className="mb-14 relative z-10">
          <div className="w-40 h-40 rounded-full bg-white/5 flex items-center justify-center relative mb-8 mx-auto">
            <AnimatePresence>
              {isActive && (
                <>
                  <motion.div 
                    animate={{ scale: [1, 1.4, 1], opacity: [0.1, 0.3, 0.1] }}
                    transition={{ repeat: Infinity, duration: 3 }}
                    className="absolute inset-0 rounded-full bg-white"
                  />
                  <motion.div 
                    animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.4, 0.2] }}
                    transition={{ repeat: Infinity, duration: 2, delay: 0.5 }}
                    className="absolute inset-4 rounded-full border border-white/20"
                  />
                </>
              )}
            </AnimatePresence>
            <div className="w-32 h-32 rounded-full bg-white/10 border border-white/10 flex items-center justify-center font-serif italic text-5xl shadow-2xl relative z-10">
              {selectedProfile.name.charAt(0)}
            </div>
          </div>
          <h2 className="text-4xl font-serif mb-3 tracking-tight">{selectedLanguage} Mentor</h2>
          <div className="flex items-center justify-center gap-2">
            {!isConnecting && (
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }} 
                transition={{ repeat: Infinity, duration: 2 }}
                className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.5)]" 
              />
            )}
            <p className="text-white/50 text-xs tracking-[0.3em] uppercase font-black">
              {isConnecting ? 'Establishing Line...' : 'Voice Encryption Active'}
            </p>
          </div>
        </div>

        <div className="flex-1 w-full min-h-[120px] mb-12 relative z-10 bg-white/5 rounded-[2rem] p-6 backdrop-blur-sm border border-white/5 flex items-center justify-center">
          <p className="text-xl italic font-serif leading-relaxed opacity-90 transition-all duration-500">
            {modelResponse || (isConnecting ? "Taiyyar ho jayein..." : "Kuch poohein, main sun rahi hoon...")}
          </p>
        </div>

        {/* Profile Selection */}
        <div className="w-full mb-12 relative z-10">
          <div className="text-[10px] uppercase tracking-[0.2em] font-black opacity-30 mb-4">Available Specialists</div>
          <div className="grid grid-cols-5 gap-2.5">
            {MENTOR_PROFILES.map((p) => (
              <motion.button
                key={p.id}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedProfileId(p.id)}
                className={cn(
                  "p-3 rounded-2xl border transition-all flex flex-col items-center gap-1",
                  selectedProfileId === p.id 
                    ? "bg-white text-[#3D3D2B] border-white shadow-[0_10px_20px_-5px_rgba(255,255,255,0.2)]" 
                    : "bg-white/5 text-white/40 border-white/10 hover:bg-white/10"
                )}
              >
                <span className="text-[9px] font-black uppercase tracking-tight truncate w-full">{p.name}</span>
                <span className={cn("text-[7px] font-bold opacity-50", selectedProfileId === p.id ? "text-[#3D3D2B]" : "text-white")}>
                  {p.label.split(' ')[0]}
                </span>
              </motion.button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-10 px-4 relative z-10">
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsMuted(!isMuted)}
            className={cn(
              "p-7 rounded-[2rem] transition-all border-2",
              isMuted 
                ? "bg-red-500/20 border-red-500/50 text-red-500" 
                : "bg-white/10 border-white/20 text-white hover:bg-white/20 shadow-lg"
            )}
          >
            {isMuted ? <MicOff size={32} /> : <Mic size={32} />}
          </motion.button>

          <div className="flex flex-col items-center gap-4">
            <motion.button 
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="p-10 rounded-full bg-red-600 text-white shadow-[0_20px_40px_-10px_rgba(220,38,38,0.5)] hover:bg-red-700 transition-all"
            >
              <PhoneOff size={40} strokeWidth={2.5} />
            </motion.button>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40">Disconnect</span>
          </div>

          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={stopAiTalking}
            className={cn(
              "p-7 rounded-[2rem] transition-all border-2",
              isPlayingRef.current || modelResponse
                ? "bg-amber-500/20 border-amber-500/50 text-amber-500 hover:bg-amber-500/30 shadow-lg" 
                : "bg-white/10 border-white/20 text-white opacity-20 cursor-not-allowed"
            )}
          >
            <VolumeX size={32} />
          </motion.button>
        </div>

        <AnimatePresence>
          {isConnecting && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-12 flex items-center gap-3 text-white/50 italic text-xs font-serif"
            >
              <Loader2 className="w-4 h-4 animate-spin" />
              Synchronizing with Mentor Network...
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}
