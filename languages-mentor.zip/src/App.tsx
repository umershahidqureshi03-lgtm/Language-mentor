/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { getMentorResponseStream, generateSpeech } from './services/geminiService';
import { 
  Send, 
  Bot, 
  User, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Code2, 
  Terminal,
  Loader2,
  Trash2,
  Mic,
  Settings,
  Menu,
  X,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { cn } from './lib/utils';
import LiveCall from './components/LiveCall';

interface Message {
  role: 'user' | 'model';
  content: string;
}

export default function App() {
  const LANGUAGES = [
    { id: 'python', name: 'Python', icon: '🐍', color: '#3776AB', description: 'Beginner friendly & powerful' },
    { id: 'javascript', name: 'JavaScript', icon: '📜', color: '#F7DF1E', description: 'Learn Web Development' },
    { id: 'cpp', name: 'C++', icon: '⚙️', color: '#00599C', description: 'System & Game logic' },
    { id: 'java', name: 'Java', icon: '☕', color: '#007396', description: 'Enterprise & Android' },
    { id: 'html', name: 'HTML/CSS', icon: '🎨', color: '#E34F26', description: 'Standard Web Layout' },
    { id: 'sql', name: 'SQL', icon: '📊', color: '#4479A1', description: 'Database management' },
  ];

  const [selectedLanguage, setSelectedLanguage] = useState(LANGUAGES[0]);
  const [languageProgress, setLanguageProgress] = useState<Record<string, number>>({
    python: 15,
    javascript: 10,
    cpp: 5,
    java: 5,
    html: 20,
    sql: 5,
  });
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isQuizMode, setIsQuizMode] = useState(false);
  const lastSpeechTimeRef = useRef<number>(0);
  const apiQueueRef = useRef<string[]>([]);
  const isApiProcessingRef = useRef<boolean>(false);
  const SPEECH_COOLDOWN = 2000; // 2 seconds between API requests

  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      content: `Assalam-o-Alaikum! Main hoon ${LANGUAGES[0].name} Mentor. 😊 Aaj hum ${LANGUAGES[0].name} mein kya seekhenge? Aap mujhse koi bhi sawal pooch sakte hain ya keh sakte hain 'Start from basics'.`
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isCallActive, setIsCallActive] = useState(false);
  const [isQuotaExhausted, setIsQuotaExhausted] = useState(false);
  const [audioSource, setAudioSource] = useState<AudioBufferSourceNode | null>(null);
  const audioQueueRef = useRef<AudioBuffer[]>([]);
  const isPlayingQueueRef = useRef(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const MENTOR_PROFILES = [
    { id: 'ayesha', name: 'Ayesha', label: 'Junior Dev', age: '19', voice: 'Zephyr' },
    { id: 'zara', name: 'Zara', label: 'SW Student', age: '22', voice: 'Aoede' },
    { id: 'hina', name: 'Hina', label: 'Sr. Python Architect', age: '28', voice: 'Kore' },
    { id: 'maria', name: 'Maria', label: 'Data Specialist', age: '20', voice: 'Zephyr' },
    { id: 'sana', name: 'Sana', label: 'Backend Engineer', age: '25', voice: 'Aoede' },
    { id: 'fatima', name: 'Fatima', label: 'Tech Lead', age: '32', voice: 'Kore' },
    { id: 'noor', name: 'Noor', label: 'AI Researcher', age: '21', voice: 'Zephyr' },
    { id: 'alizeh', name: 'Alizeh', label: 'Full Stack Dev', age: '24', voice: 'Aoede' },
    { id: 'mahira', name: 'Mahira', label: 'Data Manager', age: '35', voice: 'Kore' },
    { id: 'zoya', name: 'Zoya', label: 'Flutter Dev', age: '23', voice: 'Zephyr' },
  ];

  const [selectedProfileId, setSelectedProfileId] = useState<string>(MENTOR_PROFILES[0].id);
  const selectedProfile = MENTOR_PROFILES.find(p => p.id === selectedProfileId) || MENTOR_PROFILES[0];

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'hi-IN'; // Better for Roman Urdu/Hindi accents than en-US

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        setIsRecording(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsRecording(false);
        
        // Handle specific error types
        if (event.error === 'network') {
          alert("Network error detected. Please check your internet connection and try using the keyboard for now.");
        } else if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          alert("Microphone access is denied. Please enable it in browser settings.");
        }
      };

      recognitionRef.current.onend = () => {
        setIsRecording(false);
      };
    }
  }, []);

  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
    } else {
      setIsRecording(true);
      recognitionRef.current?.start();
    }
  };

  const playNextInQueue = async () => {
    if (audioQueueRef.current.length === 0 || !audioContextRef.current) {
      isPlayingQueueRef.current = false;
      setIsSpeaking(false);
      return;
    }

    isPlayingQueueRef.current = true;
    setIsSpeaking(true);

    const buffer = audioQueueRef.current.shift()!;
    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    source.onended = () => {
      setAudioSource(null);
      playNextInQueue();
    };
    source.start();
    setAudioSource(source);
  };

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (isQuotaExhausted) {
      // Automatically attempt to reset quota state after 2 minutes
      timeout = setTimeout(() => {
        setIsQuotaExhausted(false);
        console.log("Attempting to reset TTS quota state...");
      }, 120000);
    }
    return () => clearTimeout(timeout);
  }, [isQuotaExhausted]);

  const processApiQueue = async () => {
    if (isApiProcessingRef.current || apiQueueRef.current.length === 0 || isQuotaExhausted) return;
    
    isApiProcessingRef.current = true;
    const text = apiQueueRef.current.shift();
    
    if (text) {
      try {
        const result = await generateSpeech(text, selectedProfile.voice);
        
        if (result && result.error === "QUOTA_EXHAUSTED") {
          setIsQuotaExhausted(true);
          setIsVoiceEnabled(false);
          setMessages(prev => {
            if (prev.length > 0 && prev[prev.length - 1].content.includes("Voice server reached its limit")) {
              return prev;
            }
            return [...prev, { 
              role: 'model' as const, 
              content: "System Note: Voice server reached its limit due to high traffic. I have paused the voice response, but you can still read my replies! You can try enabling voice again from the top menu later. 😊" 
            }];
          });
          apiQueueRef.current = [];
          isApiProcessingRef.current = false;
          return;
        }

        if (result && result.data) {
          const { data: base64Audio, mimeType } = result;

          if (!audioContextRef.current) {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
          }

          if (audioContextRef.current.state === 'suspended') {
            await audioContextRef.current.resume();
          }

          let audioBuffer: AudioBuffer;

          if (mimeType.includes('pcm')) {
            const binary = atob(base64Audio);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
            const pcm = new Int16Array(bytes.buffer);
            const rateMatch = mimeType.match(/rate=(\d+)/);
            const sampleRate = rateMatch ? parseInt(rateMatch[1]) : 24000;

            audioBuffer = audioContextRef.current.createBuffer(1, pcm.length, sampleRate);
            const channelData = audioBuffer.getChannelData(0);
            for (let i = 0; i < pcm.length; i++) channelData[i] = pcm[i] / 32768;
          } else {
            const response = await fetch(`data:${mimeType};base64,${base64Audio}`);
            const arrayBuffer = await response.arrayBuffer();
            try {
              audioBuffer = await audioContextRef.current.decodeAudioData(arrayBuffer);
            } catch (decodeErr) {
              const binary = atob(base64Audio);
              const bytes = new Uint8Array(binary.length);
              for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
              const pcm = new Int16Array(bytes.buffer);
              audioBuffer = audioContextRef.current.createBuffer(1, pcm.length, 24000);
              const channelData = audioBuffer.getChannelData(0);
              for (let i = 0; i < pcm.length; i++) channelData[i] = pcm[i] / 32768;
            }
          }
          
          if (audioBuffer) {
            audioQueueRef.current.push(audioBuffer);
            if (!isPlayingQueueRef.current) {
              playNextInQueue();
            }
          }
        }
      } catch (error) {
        console.error("API Speech error:", error);
      }
    }
    
    setTimeout(() => {
      isApiProcessingRef.current = false;
      processApiQueue();
    }, SPEECH_COOLDOWN);
  };

  const speak = (text: string) => {
    if (!isVoiceEnabled || !text.trim() || isQuotaExhausted) return;
    apiQueueRef.current.push(text);
    processApiQueue();
  };

  const stopPlayback = () => {
    if (audioSource) {
      try { audioSource.stop(); } catch(e) {}
      setAudioSource(null);
    }
    audioQueueRef.current = [];
    isPlayingQueueRef.current = false;
    setIsSpeaking(false);
  };

  const clearChat = () => {
    stopPlayback();
    setMessages([{
      role: 'model',
      content: isQuizMode 
        ? `Theek hai! Chalo ${selectedLanguage.name} quiz phir se shuru karte hain. 😊 Taiyar ho sawal ke liye?`
        : `Theek hai! Chalo bilkul shuru se baat karte hain. 😊 ${selectedLanguage.name} mein aaj kya seekhenge?`
    }]);
  };

  const changeLanguage = (lang: typeof LANGUAGES[0]) => {
    setSelectedLanguage(lang);
    setMessages([{
      role: 'model',
      content: isQuizMode
        ? `Suno! Tumne ${lang.name} ka quiz select kiya hai. 😊 Main tumse ${lang.name} ke technical sawalat karungi. Shuru karein?`
        : `Assalam-o-Alaikum! Main hoon ${lang.name} Mentor. 😊 Aaj hum ${lang.name} mein kya seekhenge? Aap mujhse koi bhi sawal pooch sakte hain ya keh sakte hain 'Start from basics'.`
    }]);
    setIsSidebarOpen(false);
    stopPlayback();
  };

  const toggleQuizMode = () => {
    const newQuizMode = !isQuizMode;
    setIsQuizMode(newQuizMode);
    stopPlayback();
    setMessages([{
      role: 'model',
      content: newQuizMode 
        ? `Chalo! Ab hum ${selectedLanguage.name} ka Quiz shuru karte hain. 😎 Main tumse sawal poochoongi aur tumne sahi jawab dena hai. Taiyar ho?`
        : `Assalam-o-Alaikum! Main hoon ${selectedLanguage.name} Mentor. 😊 Chalo wapis seekhne ki taraf aate hain. Aaj kya seekhna hai?`
    }]);
    setIsSidebarOpen(false);
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    let fullBotResponse = "";
    let speechBuffer = "";
    let accumulatedResponse = "";

    try {
      const updatedHistory: Message[] = [...messages, { role: 'user' as const, content: userMessage }];
      
      // Add empty message for model to stream into
      setMessages([...updatedHistory, { role: 'model' as const, content: "" }]);

      fullBotResponse = await getMentorResponseStream(selectedLanguage.name, updatedHistory, (chunk) => {
        accumulatedResponse += chunk;
        speechBuffer += chunk;

        // Update UI
        setMessages(prev => {
          const newMessages = [...prev];
          if (newMessages.length > 0) {
            newMessages[newMessages.length - 1].content = accumulatedResponse;
          }
          return newMessages;
        });

        // Trigger TTS for completed sentences or significant chunks
        if (isVoiceEnabled) {
          const sentences = speechBuffer.split(/([.!?\n۔])/);
          
          // Conditions to trigger speech:
          // 1. We have at least one complete sentence
          // 2. The buffer is long enough to justify a call (prevents 429 on tiny fragments)
          const isFirstChunk = accumulatedResponse.length === speechBuffer.length;
          
          if (sentences.length >= 2 || (isFirstChunk && speechBuffer.length > 80) || speechBuffer.length > 150) {
            let toSpeak = "";
            
            if (sentences.length >= 2 || speechBuffer.length > 150) {
              toSpeak = sentences.slice(0, -1).join('');
              speechBuffer = sentences[sentences.length - 1];
            } else {
              toSpeak = speechBuffer;
              speechBuffer = "";
            }

            const cleanedText = toSpeak.replace(/```[\s\S]*?```/g, '').trim();
            if (cleanedText && cleanedText.length > 30) {
              speak(cleanedText);
            }
          }
        }
      }, isQuizMode);

      // Speak remaining text
      if (isVoiceEnabled && speechBuffer.trim()) {
        const cleanedText = speechBuffer.replace(/```[\s\S]*?```/g, '').trim();
        if (cleanedText) {
          speak(cleanedText);
        }
      }

      // Update Real Progress
      setLanguageProgress(prev => {
        const currentProgress = prev[selectedLanguage.id] || 0;
        const increment = isQuizMode ? 10 : 4; // Quizzes give more mastery faster
        const newProgress = Math.min(100, currentProgress + increment);
        return { ...prev, [selectedLanguage.id]: newProgress };
      });
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => {
        const newMessages = [...prev];
        if (newMessages[newMessages.length - 1].content === "") {
          newMessages[newMessages.length - 1].content = "Maaf kijiye, lagta hai internet mein kuch masla hai. 😅 Phir se try karein?";
        }
        return newMessages;
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#f8f7f2] font-sans text-[#4a4a3a] overflow-hidden">
      {/* Mobile Menu Toggle */}
      <button 
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        className="fixed top-6 left-4 z-50 p-2.5 rounded-xl bg-[#5A5A40] text-white shadow-lg md:hidden"
      >
        {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 z-30 bg-black/40 backdrop-blur-sm md:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-40 w-80 bg-[#3D3D2B] text-[#fdfcf8] flex flex-col p-8 transition-transform duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] md:relative md:translate-x-0 shrink-0 shadow-2xl border-r border-white/5",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="mb-12 pt-10 md:pt-0">
          <motion.h1 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-4xl font-serif italic mb-2 tracking-tight"
          >
            Code Studio
          </motion.h1>
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: '40px' }}
            className="h-1 bg-[#FFD700] rounded-full mb-3"
          />
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            transition={{ delay: 0.2 }}
            className="text-[9px] tracking-[0.4em] uppercase font-black"
          >
            Elite Multi-Language Lab
          </motion.p>
        </div>
        
        <nav className="flex-1 space-y-10 overflow-y-auto custom-scrollbar pr-2 -mr-2">
          <div className="space-y-4">
            <div className="text-[10px] uppercase tracking-[0.25em] font-black opacity-30 px-3">Learning Path</div>
            <motion.div 
              className="grid gap-3"
              variants={{
                show: { transition: { staggerChildren: 0.08 } }
              }}
              initial="hidden"
              animate="show"
            >
              {LANGUAGES.map((lang) => (
                <motion.button
                  key={lang.id}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: { opacity: 1, y: 0 }
                  }}
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => changeLanguage(lang)}
                  className={cn(
                    "w-full flex items-center gap-4 p-4 rounded-[2rem] transition-all text-left relative group overflow-hidden border",
                    selectedLanguage.id === lang.id
                      ? "bg-white text-[#3D3D2B] shadow-[0_20px_40px_-10px_rgba(0,0,0,0.4)] z-10 border-white"
                      : "bg-[#ffffff03] hover:bg-[#ffffff08] border-white/5 text-white/60 hover:text-white"
                  )}
                >
                  <div className={cn(
                    "w-12 h-12 rounded-2xl flex items-center justify-center text-2xl transition-all duration-500",
                    selectedLanguage.id === lang.id ? "bg-[#3D3D2B]/5 rotate-3" : "bg-white/5 group-hover:rotate-12"
                  )}>
                    {lang.icon}
                  </div>
                  <div className="flex-1">
                    <div className="text-[14px] font-black tracking-tight leading-none mb-1">{lang.name}</div>
                    <div className={cn(
                      "text-[10px] font-bold transition-opacity", 
                      selectedLanguage.id === lang.id ? "text-[#3D3D2B]/50" : "text-white/30"
                    )}>
                      {lang.description}
                    </div>
                  </div>
                  {selectedLanguage.id === lang.id && (
                    <motion.div layoutId="active-indicator" className="absolute right-4 text-[#3D3D2B]">
                      <ChevronRight size={16} />
                    </motion.div>
                  )}
                </motion.button>
              ))}
            </motion.div>
          </div>

          <div className="space-y-4 pt-6 border-t border-white/5">
            <div className="text-[10px] uppercase tracking-[0.25em] font-black opacity-30 px-3">Session Mode</div>
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => isQuizMode && toggleQuizMode()}
                className={cn(
                  "p-5 rounded-[2.5rem] flex flex-col items-center gap-2 transition-all border group",
                  !isQuizMode 
                    ? "bg-white text-[#3D3D2B] border-white shadow-xl scale-105" 
                    : "bg-white/5 text-white/40 border-white/5 hover:bg-white/10"
                )}
              >
                <Code2 size={24} className={cn(!isQuizMode ? "text-[#3D3D2B]" : "text-white/20 group-hover:text-white/40")} />
                <span className="text-[10px] font-black uppercase tracking-widest">Learn</span>
              </button>
              <button 
                onClick={() => !isQuizMode && toggleQuizMode()}
                className={cn(
                  "p-5 rounded-[2.5rem] flex flex-col items-center gap-2 transition-all border group",
                  isQuizMode 
                    ? "bg-[#FFD700] text-[#3D3D2B] border-[#FFD700] shadow-xl scale-105" 
                    : "bg-white/5 text-white/40 border-white/5 hover:bg-white/10"
                )}
              >
                <Sparkles size={24} className={cn(isQuizMode ? "text-[#3D3D2B]" : "text-white/20 group-hover:text-white/40")} />
                <span className="text-[10px] font-black uppercase tracking-widest">Quiz</span>
              </button>
            </div>
          </div>
          
          <div className="space-y-4 pt-8 border-t border-[#ffffff10]">
            <div className="text-[10px] uppercase tracking-[0.2em] font-black opacity-30 px-2">Knowledge Graph</div>
            <motion.div 
              key={selectedLanguage.id + '-' + languageProgress[selectedLanguage.id]}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white/5 p-6 rounded-[2.5rem] border border-[#ffffff08] backdrop-blur-sm"
            >
              <div className="text-[10px] mb-2 opacity-50 font-bold uppercase tracking-widest leading-none">Module Status</div>
              <div className="font-serif text-xl leading-tight mb-6">{selectedLanguage.name} Essential Concepts</div>
              
              <div className="relative h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${languageProgress[selectedLanguage.id]}%` }}
                  transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
                  className="absolute inset-y-0 left-0 bg-white shadow-[0_0_15px_rgba(255,255,255,0.5)]" 
                />
              </div>
              <div className="flex justify-between mt-3">
                <span className="text-[10px] font-bold opacity-40">Mastery Level</span>
                <span className="text-[10px] font-bold text-white transition-all tabular-nums">
                  {languageProgress[selectedLanguage.id]}%
                </span>
              </div>
            </motion.div>
          </div>
        </nav>

        <div className="mt-8">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#2a2a1d] p-6 rounded-[2rem] border border-[#ffffff05] relative overflow-hidden"
          >
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-white/5 rounded-full blur-2xl" />
            <p className="text-[13px] italic opacity-80 leading-relaxed font-serif relative z-10">
              "Programming is the art of algorithm design and the craft of debugging loops."
            </p>
          </motion.div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative min-w-0 bg-[#FDFCF8]">
        {/* Header */}
        <header className="flex justify-between items-center px-12 py-10 bg-white/60 backdrop-blur-2xl sticky top-0 z-20 border-b border-[#E8E6D9]/40">
          <div className="pl-12 md:pl-0">
            <motion.div
              key={selectedLanguage.id + (isQuizMode ? '-quiz' : '-learn')}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h2 className="text-4xl font-serif text-[#1C1C1B] tracking-tighter mb-1">
                {selectedLanguage.name} <span className="italic font-normal opacity-40">{isQuizMode ? 'Challenge' : 'Lab'}</span>
              </h2>
              <div className="flex items-center gap-2 opacity-60">
                <div className="w-1.5 h-1.5 rounded-full bg-[#3D3D2B]" />
                <p className="text-[10px] text-[#5A5A4D] font-black uppercase tracking-[0.3em]">
                  {isQuizMode ? 'Performance assessment Active' : `Deep-dive ${selectedLanguage.name} development`}
                </p>
              </div>
            </motion.div>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Voice Model Selector */}
            <div className="hidden lg:flex items-center bg-white border border-[#E8E6D9] rounded-3xl px-5 py-1 shadow-sm hover:border-[#3D3D2B]/20 transition-all group">
              <span className="text-[9px] font-black text-[#3D3D2B] uppercase mr-3 opacity-30 group-hover:opacity-100 transition-opacity">Expert Profile</span>
              <select 
                value={selectedProfileId}
                onChange={(e) => setSelectedProfileId(e.target.value)}
                className="bg-transparent py-4 text-[12px] font-bold text-[#3D3D2B] focus:outline-none cursor-pointer pr-4 appearance-none"
              >
                {MENTOR_PROFILES.map((p) => (
                  <option key={p.id} value={p.id}>
                     {p.name} — {p.label}
                  </option>
                ))}
              </select>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                if (isQuotaExhausted) {
                  setIsQuotaExhausted(false);
                  setIsVoiceEnabled(true);
                  return;
                }
                setIsVoiceEnabled(!isVoiceEnabled);
              }}
              className={cn(
                "hidden sm:flex items-center gap-3 px-6 py-4 rounded-[1.75rem] border transition-all text-[10px] font-black uppercase tracking-widest",
                isVoiceEnabled 
                  ? "bg-white border-[#E8E6D9] text-[#3D3D2B] shadow-sm active:shadow-inner" 
                  : (isQuotaExhausted ? "bg-amber-50 border-amber-200 text-amber-700" : "bg-[#FAF9F6] border-[#E8E6D9] text-[#7A7A66]")
              )}
            >
              {isVoiceEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
              <span>{isQuotaExhausted ? "Retry" : (isVoiceEnabled ? "Voice On" : "Muted")}</span>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setIsCallActive(true)}
              className="flex items-center gap-3 bg-[#3D3D2B] text-white px-8 py-4 rounded-full shadow-[0_25px_40px_-15px_rgba(61,61,43,0.3)] hover:bg-[#1C1C1B] transition-all relative overflow-hidden group border border-[#ffffff10]"
            >
              <div className="absolute inset-0 bg-white/10 -translate-x-full group-hover:translate-x-0 transition-transform duration-500" />
              <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_10px_#ef4444] animate-pulse relative z-10" />
              <span className="text-[11px] font-black uppercase tracking-[0.2em] relative z-10">Connect Live</span>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.1, rotate: -5 }}
              whileTap={{ scale: 0.9 }}
              onClick={clearChat}
              className="p-3.5 rounded-2xl bg-white border border-[#E8E6D9] text-[#7A7A66] hover:text-red-600 hover:border-red-200 hover:bg-red-50 transition-all shadow-sm"
              title="Reset Chat"
            >
              <Trash2 size={20} />
            </motion.button>
          </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto px-10 py-10 custom-scrollbar bg-[#FDFCF8]">
          <div className="max-w-4xl mx-auto space-y-10">
            <AnimatePresence mode="popLayout">
              {messages.map((message, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 40, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ 
                    type: "spring", 
                    stiffness: 140, 
                    damping: 18,
                    delay: 0.05
                  }}
                  className={cn(
                    "flex gap-8",
                    message.role === 'user' ? "flex-row-reverse" : "flex-row"
                  )}
                >
                  <motion.div 
                    whileHover={{ scale: 1.1, rotate: message.role === 'user' ? -5 : 5 }}
                    className={cn(
                      "w-14 h-14 rounded-[1.5rem] flex items-center justify-center shrink-0 mt-1 shadow-2xl font-serif italic text-xl transition-transform border tracking-tighter",
                      message.role === 'user' ? "bg-[#3D3D2B] text-white border-white/10" : "bg-white text-[#3D3D2B] border-[#E8E6D9]"
                    )}
                  >
                    {message.role === 'user' ? 'U' : selectedProfile.name.charAt(0)}
                  </motion.div>
                  
                  <div className={cn(
                    "max-w-[80%] rounded-[3rem] px-10 py-8 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.06)] border leading-relaxed text-[16px] relative group/msg transition-all duration-300",
                    message.role === 'user' 
                      ? "bg-[#3D3D2B] text-[#FFFDF8] rounded-tr-none border-white/5 hover:shadow-2xl" 
                      : "bg-white text-[#2D2D2A] rounded-tl-none border-[#E8E6D9]/50 hover:shadow-2xl"
                  )}>
                    {message.role === 'model' && (
                      <motion.button
                        initial={{ opacity: 0, scale: 0.8 }}
                        whileHover={{ scale: 1.15 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => {
                          const textToSpeak = message.content.replace(/```[\s\S]*?```/g, '').trim();
                          if (textToSpeak) speak(textToSpeak);
                        }}
                        className="absolute -right-14 top-4 p-4 rounded-full bg-white border border-[#E8E6D9] text-[#7A7A66] opacity-0 group-hover/msg:opacity-100 transition-all hover:text-[#3D3D2B] hover:border-[#3D3D2B]/30 shadow-xl"
                      >
                        <Volume2 size={18} />
                      </motion.button>
                    )}
                    <div className={cn(
                      "markdown-body",
                      message.role === 'user' ? "text-[#FFFDF8]" : "text-[#2D2D2A]"
                    )}>
                      <ReactMarkdown
                        components={{
                          p({ children }) {
                            return <p className="mb-6 last:mb-0 leading-[1.7] font-medium text-[15px]">{children}</p>;
                          },
                          ul({ children }) {
                            return <ul className="pl-6 list-disc space-y-3 mb-6 marker:text-[#3D3D2B]/30">{children}</ul>;
                          },
                          ol({ children }) {
                            return <ol className="pl-6 list-decimal space-y-3 mb-6 marker:text-[#3D3D2B]/30">{children}</ol>;
                          },
                          h1({ children }) { return <h1 className="text-3xl font-serif font-black mb-6 tracking-tighter">{children}</h1> },
                          h2({ children }) { return <h2 className="text-2xl font-serif font-black mb-5 tracking-tighter">{children}</h2> },
                          h3({ children }) { return <h3 className="text-xl font-serif font-black mb-4 tracking-tighter">{children}</h3> },
                          code({ className, children, ...props }) {
                            const match = /language-(\w+)/.exec(className || '');
                            const isInline = !match;
                            return !isInline ? (
                              <div className="relative group my-8 overflow-hidden shadow-3xl rounded-[2.5rem] border border-white/5 ring-1 ring-black/5">
                                <div className="absolute top-5 left-8 flex gap-2 opacity-50 group-hover:opacity-100 transition-opacity z-10">
                                  <div className="w-3 h-3 rounded-full bg-[#FF5F56] shadow-[0_0_8px_rgba(255,95,86,0.3)]" />
                                  <div className="w-3 h-3 rounded-full bg-[#FFBD2E] shadow-[0_0_8px_rgba(255,189,46,0.3)]" />
                                  <div className="w-3 h-3 rounded-full bg-[#27C93F] shadow-[0_0_8px_rgba(39,201,63,0.3)]" />
                                </div>
                                <div className="absolute top-5 right-8 text-[11px] uppercase font-black tracking-[0.3em] text-white/15 z-10">
                                  {match[1]} Professional
                                </div>
                                <SyntaxHighlighter
                                  language={match[1]}
                                  style={atomDark}
                                  customStyle={{
                                    margin: 0,
                                    padding: '5rem 2.5rem 2.5rem 2.5rem',
                                    fontSize: '0.95rem',
                                    background: '#0F0F0F',
                                    lineHeight: '1.7',
                                    fontFamily: '"JetBrains Mono", monospace'
                                  }}
                                >
                                  {String(children).replace(/\n$/, '')}
                                </SyntaxHighlighter>
                              </div>
                            ) : (
                              <code className={cn(
                                "px-2.5 py-1 rounded-xl font-mono text-[13px] border transition-colors",
                                message.role === 'user' 
                                  ? "bg-white/10 border-white/10 text-white" 
                                  : "bg-[#F3F1E9] border-[#E8E6D9] text-[#3D3D2B] font-bold"
                              )} {...props}>
                                {children}
                              </code>
                            );
                          }
                        }}
                      >
                        {message.content}
                      </ReactMarkdown>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            
            {isLoading && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex gap-6">
                <div className="w-12 h-12 rounded-[1.25rem] bg-[#e8e6d9] text-[#3D3D2B] flex items-center justify-center shrink-0 mt-1 font-serif italic text-lg shadow-sm">
                  P
                </div>
                <div className="bg-white border border-[#e8e6d9]/60 rounded-[2rem] rounded-tl-none px-8 py-5 flex items-center gap-4 text-[#7a7a6a] shadow-sm">
                  <div className="flex gap-1.5">
                    <motion.div animate={{ scale: [1, 1.4, 1], opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 0.8 }} className="w-1.5 h-1.5 rounded-full bg-[#3D3D2B]" />
                    <motion.div animate={{ scale: [1, 1.4, 1], opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 0.8, delay: 0.2 }} className="w-1.5 h-1.5 rounded-full bg-[#3D3D2B]" />
                    <motion.div animate={{ scale: [1, 1.4, 1], opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 0.8, delay: 0.4 }} className="w-1.5 h-1.5 rounded-full bg-[#3D3D2B]" />
                  </div>
                  <span className="text-[13px] font-bold italic tracking-tight opacity-60">Mentor is formulating a response...</span>
                </div>
              </motion.div>
            )}
            <div ref={chatEndRef} />
          </div>
        </div>

        {/* Input Area */}
        <footer className="px-10 py-8 bg-white/50 backdrop-blur-md border-t border-[#e8e6d9]/60 shadow-[0_-10px_40px_-5px_rgba(0,0,0,0.03)]">
          <div className="max-w-4xl mx-auto">
            <div className="flex gap-4 items-end">
              <div className="relative flex-1 group">
                <textarea
                  rows={1}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder={`${selectedLanguage.name} ke baare mein kuch poochein...`}
                  className="w-full bg-white border border-[#e8e6d9] rounded-[1.75rem] px-8 py-5 pr-14 text-[#4a4a3a] placeholder:text-[#a1a190] focus:outline-none focus:ring-[6px] focus:ring-[#3D3D2B]/5 focus:border-[#3D3D2B]/40 transition-all resize-none max-h-48 shadow-sm text-base leading-relaxed"
                />
                <div className="absolute top-4 right-5 flex items-center gap-2">
                  <AnimatePresence>
                    {isSpeaking && (
                      <motion.button
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        onClick={(e) => {
                          e.stopPropagation();
                          stopPlayback();
                        }}
                        className="p-3 rounded-2xl bg-amber-50 text-amber-600 hover:bg-amber-100 transition-all shadow-sm flex items-center gap-2"
                      >
                        <VolumeX size={18} strokeWidth={2.5} />
                        <span className="text-[10px] font-black uppercase tracking-tight">Stop</span>
                      </motion.button>
                    )}
                  </AnimatePresence>

                  <AnimatePresence>
                    {isRecording && (
                      <motion.div 
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="flex items-center gap-2 bg-red-50 px-4 py-2 rounded-full border border-red-100/50"
                      >
                        <div className="flex gap-1 items-end h-3.5">
                          {[1, 2, 3, 4].map((i) => (
                            <motion.div
                              key={i}
                              animate={{ height: [4, 14, 4] }}
                              transition={{ repeat: Infinity, duration: 0.5, delay: i * 0.1 }}
                              className="w-0.5 bg-red-500 rounded-full"
                            />
                          ))}
                        </div>
                        <span className="text-[10px] font-black text-red-600 uppercase tracking-tight">Listening</span>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={toggleRecording}
                    className={cn(
                      "p-3 rounded-2xl transition-all shadow-md flex items-center justify-center relative",
                      isRecording 
                        ? "bg-red-600 text-white shadow-red-200 pulse-glow" 
                        : "bg-[#F8F7F2] text-[#3D3D2B] border border-[#e8e6d9] hover:bg-[#3D3D2B] hover:text-white"
                    )}
                  >
                    <Mic size={20} strokeWidth={isRecording ? 3 : 2} />
                  </motion.button>
                </div>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className={cn(
                  "p-5 rounded-[1.75rem] shadow-xl transition-all disabled:opacity-50 disabled:grayscale",
                  "bg-[#3D3D2B] text-white hover:bg-[#2a2a1d] shadow-[#3D3D2B]/20"
                )}
              >
                <Send size={26} strokeWidth={2.5} />
              </motion.button>
            </div>
            
            <div className="flex justify-between items-center mt-6">
              <div className="flex gap-4 opacity-30">
                <span className="text-[9px] uppercase tracking-widest font-black">⌘ Enter for send · Shift for multiline</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles size={12} className="text-[#3D3D2B] opacity-30" />
                <p className="text-[9px] text-[#3D3D2B]/30 uppercase tracking-[0.3em] font-black">
                  Elite {selectedLanguage.name} Mentor Platform
                </p>
              </div>
            </div>
          </div>
        </footer>

        <style>{`
          .custom-scrollbar::-webkit-scrollbar {
            width: 5px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #e1e0d7;
            border-radius: 10px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #d1d0c5;
          }
          @keyframes pulse-glow {
            0% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(220, 38, 38, 0); }
            100% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0); }
          }
          .pulse-glow {
            animation: pulse-glow 2s infinite;
          }
        `}</style>
        <AnimatePresence>
          {isCallActive && (
            <LiveCall 
              onClose={() => setIsCallActive(false)} 
              initialProfileId={selectedProfileId}
              selectedLanguage={selectedLanguage.name}
              isQuizMode={isQuizMode}
            />
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
